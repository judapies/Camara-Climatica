﻿# OPEN SOURCE LICENSE
# END-USER LICENSE AGREEMENT

**For Free Serial Port Monitor [RS232 Data Logger]**

**By Eltima Software**

## NOTICE TO USER:

Please read this carefully. By using all or any portion of the Software you accept all the terms and conditions of this Agreement. If you do not agree, do not use this Software.

## 1. DEFINITIONS

When used in this Agreement, the following terms shall have the respective meanings indicated, such meanings to be applicable to both the singular and plural forms of the terms defined:

“Licensor” means Eltima Software.

“Software” means (a) all of the contents of the files, disk(s), CD-ROM(s) or other media with which this Agreement is provided, including but not limited to ((i) digital images, stock photographs, clip art, sounds or other artistic works (“Stock Files”); (ii) related explanatory written materials or files (“Documentation”); and (iii) fonts; and (b) upgrades, modified versions, updates, additions, and copies of the Software, if any, licensed to You by Eltima Software (collectively, “Updates”).

“Use” or “Using” means to access, install, download, copy or otherwise benefit from using the functionality of the Software in accordance with the Documentation.

“Licensee” means You or Your Company, unless otherwise indicated.

## 2. GENERAL USE

You are granted a non-exclusive License to Use the Software for any purposes for an unlimited period of time. The Software under this License is provided free of charge. Even though a license fee is not paid for the use of such software, it does not mean that there are no conditions for using such software:

* Redistributions of source code must retain the copyright notice and this list of conditions.
* Redistributions in binary form must reproduce the copyright notice and this list of conditions in the documentation and/or other materials provided with the distribution.
* The Licensee can redistribute and use in source and binary forms, with or without modification, the Software without restrictions, including without limitation the rights to use, copy, modify, merge and distribute the Software on condition that money or fees for the Software product may not be charged, except to cover distribution costs.
* The Licensor’s name may not be used to promote products derived from this Software without the Licensor’s prior written permission.
* The License doesn’t include redistribution or customization rights on the graphical user interface (GUI).
* The Licensee will not have any proprietary rights in and to the Software. The Licensee acknowledges and agrees that the Licensor retains all copyrights and other proprietary rights in and to the Software.
* Use within the scope of this License is free of charge and no royalty or licensing fees shall be paid by the Licensee.

## 3. INTELLECTUAL PROPERTY RIGHTS

This License does not transmit any intellectual rights on the Software. The Software and any copies that the Licensee is authorized to make are the intellectual property of and are owned by the Licensor. Any copies that the Licensee is permitted to make pursuant to this Agreement must contain the same copyright and other proprietary notices that appear on or in the Software.

## 4. WARRANTY

4.1 The Licensor warrants that:

4.1.1 it owns the Software and documentation and/or is in possession of valid and existing licenses that support the terms of this Agreement;

4.1.2 to the best of its knowledge, the Software does not infringe upon or violate any intellectual property right of a third party;

4.1.3 the Software does not contain any back door, time bomb, drop dead device or other routine intentionally designed by the Licensor to disable a computer program or computer instructions that alter, destroy or inhibit the processing environment.

4.2 Except those warranties specified in section 4.1 above, the Software is being delivered to the Licensee “AS IS” and the Licensor makes no warranty as to its use or performance.

The Licensor does not and cannot warrant the performance or results the Licensee may obtain by using the Software.

The Licensor gives no warranty, express or implied, that (i) the Software will be of satisfactory quality, suitable for any particular purpose or for any particular use under specified conditions, notwithstanding that such purpose, use, or conditions may be known to the Licensor; or (ii) that the Software will operate error free or without interruption or that any errors will be corrected.

## 5. LIMITATION OF LIABILITY

In no event will the Licensor be liable for any damages, claims or costs whatsoever or any consequential, indirect, incidental damages, or any lost profits or lost savings, even if the Licensor has been advised of the possibility of such loss, damages, claims or costs or for any claim by any third party.

In no event will the Licensee be liable to the Licensor on condition that the Licensee complies with all terms and conditions stated in this License.

## 6. NON-WAIVER

If a portion of this Agreement is held unenforceable, the remainder shall be valid. It means that if one section of the Agreement is not lawful, the rest of the Agreement is still in force. A party’s failure to exercise any right under this Agreement will not constitute a waiver of (a) any other terms or conditions of this Agreement, or (b) a right at any time thereafter to require exact and strict compliance with the terms of this Agreement.

© 2000-2019 Eltima Software. All rights reserved.