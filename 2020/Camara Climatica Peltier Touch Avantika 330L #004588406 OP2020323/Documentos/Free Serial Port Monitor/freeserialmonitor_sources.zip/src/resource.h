//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Port2File.rc
//
#define IDM_ABOUTBOX                    16
#define IDS_ABOUTBOX                    101
#define IDD_PORT2FILE_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDB_BMP_HEAD                    132
#define IDB_SPM                         134
#define IDC_CB_BAUDRATE                 1005
#define IDC_CB_DATABITS                 1006
#define IDC_CB_PARITY                   1007
#define IDC_CB_STOPBITS                 1008
#define IDC_CB_FC                       1009
#define IDC_EDIT2                       1010
#define IDC_ED_LOGFILE                  1010
#define IDC_BT_VIEW                     1011
#define IDC_CHECK_APPEND                1015
#define IDC_LIST_PORTS                  1018
#define IDC_BT_STARTLOG                 1019
#define IDC_STATIC_2                    1025
#define IDC_STATIC_3                    1026
#define IDC_STATIC_4                    1027
#define IDC_STATIC_5                    1028
#define IDC_STATIC_6                    1029
#define IDC_STATIC_9                    1031
#define IDC_STATIC_A                    1032
#define IDC_BT_HELP                     1033
#define IDC_STATIC_HOME                 1034
#define IDC_STATIC_STATUS               1037
#define IDC_STATIC_RECV                 1038
#define IDC_STATIC_TOTAL                1039
#define IDC_BT_HIDE                     1040
#define IDC_BTN_LEARN                   1040
#define IDC_STATIC_CAPTION              1041
#define IDC_STATIC_TEXT                 1042
#define IDC_STATIC_HYPERLINK            1043
#define IDC_STATIC_AD                   1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
